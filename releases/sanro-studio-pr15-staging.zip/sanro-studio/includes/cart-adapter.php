<?php
defined('ABSPATH') || exit;

/**
 * Explicit staging-only WooCommerce cart adapter. Never registers a public
 * endpoint or hook. The owner-authorized contract is supplied transiently by
 * the caller; owner credentials must not enter WC session/cart metadata.
 */
function sanro_studio_stage_add_cart_lines($contract, $cart) {
    if (!defined('SANRO_STUDIO_ENABLE_STAGING_CART')
        || SANRO_STUDIO_ENABLE_STAGING_CART !== true
        || !function_exists('sanro_studio_prepare_size_cart_lines')
        || !function_exists('sanro_studio_validate_size_cart_lines')
        || !is_object($cart) || !method_exists($cart, 'add_to_cart')
        || !method_exists($cart, 'remove_cart_item')
        || !method_exists($cart, 'get_cart')
        || !function_exists('get_woocommerce_currency')
        || get_woocommerce_currency() !== 'IDR') {
        return ['valid' => false, 'error' => 'staging_cart_disabled'];
    }
    $prepared = sanro_studio_prepare_size_cart_lines($contract);
    if (empty($prepared['valid'])) return $prepared;
    $verified = sanro_studio_validate_size_cart_lines($contract, $prepared['lines']);
    if (empty($verified['valid'])) return $verified;
    // Reject product configurations that require separate variation IDs or
    // extra options. These need a dedicated variation-aware adapter.
    if (!function_exists('wc_get_product')) {
        return ['valid' => false, 'error' => 'product_unavailable'];
    }
    $product = wc_get_product($contract['product_id']);
    if (!$product || !method_exists($product, 'is_type')
        || !$product->is_type('simple')
        || !method_exists($product, 'is_purchasable')
        || !$product->is_purchasable()) {
        return ['valid' => false, 'error' => 'unsupported_product_type'];
    }
    // Do not touch an existing cart: price calculation and rollback are not
    // yet integrated with WooCommerce totals and session restoration.
    if (count($cart->get_cart()) !== 0) {
        return ['valid' => false, 'error' => 'cart_must_be_empty'];
    }
    // Read-only candidate output for the future transactional adapter.
    // Calling add_to_cart here before server-owned unit-price hooks exist
    // would silently charge the product's ordinary catalog price.
    return ['valid' => true, 'lines' => $prepared['lines'],
        'requires_price_hook' => true, 'cart_mutation_enabled' => false];
}

/**
 * Apply a server-authorized per-size unit price to a WooCommerce cart product
 * object. Caller must reauthorize the draft and pass its fresh quote; no
 * client-provided amount is trusted. No global price hook is registered.
 */
function sanro_studio_stage_price_cart_line($contract, $line, $product) {
    if (!defined('SANRO_STUDIO_ENABLE_STAGING_CART')
        || SANRO_STUDIO_ENABLE_STAGING_CART !== true
        || !is_object($product) || !method_exists($product, 'set_price')
        || !function_exists('get_woocommerce_currency')
        || get_woocommerce_currency() !== 'IDR') {
        return ['valid' => false, 'error' => 'staging_pricing_disabled'];
    }
    $expected = sanro_studio_prepare_size_cart_lines($contract);
    if (empty($expected['valid'])) return $expected;
    if (!is_array($line) || !isset($line['sanro_studio_size'])
        || !is_string($line['sanro_studio_size'])) {
        return ['valid' => false, 'error' => 'invalid_cart_line'];
    }
    $matched = null;
    foreach ($expected['lines'] as $candidate) {
        if ($candidate['sanro_studio_size'] === $line['sanro_studio_size']) {
            $matched = $candidate;
            break;
        }
    }
    if ($matched === null) return ['valid' => false, 'error' => 'unknown_cart_size'];
    foreach (['product_id', 'quantity', 'sanro_studio_design_id',
        'sanro_studio_size', 'sanro_studio_unit_price',
        'sanro_studio_line_subtotal', 'sanro_studio_quote_currency'] as $key) {
        if (!array_key_exists($key, $line) || $line[$key] !== $matched[$key]) {
            return ['valid' => false, 'error' => 'cart_line_mismatch'];
        }
    }
    $product->set_price((string) $matched['sanro_studio_unit_price']);
    return ['valid' => true, 'unit_price' => $matched['sanro_studio_unit_price'],
        'currency' => 'IDR', 'requires_totals_recalculation' => true];
}

/**
 * Price every line only after the complete cart matches a fresh server quote.
 * This method is for an isolated staging transaction; no WooCommerce hook is
 * attached automatically. Caller must recalculate WC totals afterwards.
 */
function sanro_studio_stage_price_cart_batch($contract, $cart_lines) {
    if (!defined('SANRO_STUDIO_ENABLE_STAGING_CART')
        || SANRO_STUDIO_ENABLE_STAGING_CART !== true
        || !is_array($cart_lines)) {
        return ['valid' => false, 'error' => 'staging_pricing_disabled'];
    }
    $snapshots = [];
    foreach ($cart_lines as $line) {
        if (!is_array($line) || !isset($line['data'])
            || !is_object($line['data']) || !method_exists($line['data'], 'set_price')) {
            return ['valid' => false, 'error' => 'invalid_cart_product'];
        }
        $snapshot = $line;
        unset($snapshot['data']);
        $snapshots[] = $snapshot;
    }
    $verified = sanro_studio_validate_size_cart_lines($contract, $snapshots);
    if (empty($verified['valid'])) return $verified;
    // No product price is mutated until every line has passed validation.
    foreach ($cart_lines as $line) {
        $priced = sanro_studio_stage_price_cart_line($contract, $line, $line['data']);
        if (empty($priced['valid'])) return $priced;
    }
    return ['valid' => true, 'total_quantity' => $verified['total_quantity'],
        'total_price' => $verified['total_price'], 'requires_totals_recalculation' => true];
}

/**
 * After WooCommerce calculate_totals(), ensure plugins/hooks did not change
 * sizes, quantity, quote metadata or product unit prices. Staging-only.
 * This does not authorize checkout and does not trust a client price.
 */
function sanro_studio_stage_verify_cart_prices($contract, $cart) {
    if (!is_object($cart) || !method_exists($cart, 'get_cart')) {
        return ['valid' => false, 'error' => 'cart_unavailable'];
    }
    $expected = sanro_studio_prepare_size_cart_lines($contract);
    if (empty($expected['valid'])) return $expected;
    $actual = $cart->get_cart();
    if (!is_array($actual) || count($actual) !== count($expected['lines'])) {
        return ['valid' => false, 'error' => 'cart_line_count_mismatch'];
    }
    $snapshots = [];
    $prices = [];
    foreach ($expected['lines'] as $line) {
        $prices[$line['sanro_studio_size']] = $line['sanro_studio_unit_price'];
    }
    foreach ($actual as $line) {
        if (!is_array($line) || !isset($line['data'])
            || !is_object($line['data']) || !method_exists($line['data'], 'get_price')
            || !isset($line['sanro_studio_size'])
            || !is_string($line['sanro_studio_size'])
            || !isset($prices[$line['sanro_studio_size']])) {
            return ['valid' => false, 'error' => 'cart_price_unavailable'];
        }
        $actual_price = $line['data']->get_price();
        if ((!is_string($actual_price) && !is_int($actual_price) && !is_float($actual_price))
            || !preg_match('/^(?:0|[1-9][0-9]*)(?:\\.0{1,2})?$/D', (string) $actual_price)
            || (float) $actual_price !== (float) $prices[$line['sanro_studio_size']]) {
            return ['valid' => false, 'error' => 'cart_price_mismatch'];
        }
        unset($line['data']);
        $snapshots[] = $line;
    }
    return sanro_studio_validate_size_cart_lines($contract, $snapshots);
}

/**
 * Opt-in staging transaction: add a complete, empty-cart design batch, apply
 * verified per-size prices and recalculate totals. No endpoint/hook is exposed.
 * A separate checkout/session gate is still required before buyer use.
 */
function sanro_studio_stage_commit_cart_lines($contract, $cart) {
    if (!defined('SANRO_STUDIO_ENABLE_STAGING_CART_COMMIT')
        || SANRO_STUDIO_ENABLE_STAGING_CART_COMMIT !== true
        || !defined('SANRO_STUDIO_ENABLE_STAGING_CHECKOUT_HOOK')
        || SANRO_STUDIO_ENABLE_STAGING_CHECKOUT_HOOK !== true
        || !is_object($cart) || !method_exists($cart, 'calculate_totals')) {
        return ['valid' => false, 'error' => 'cart_commit_disabled'];
    }
    $preflight = sanro_studio_stage_add_cart_lines($contract, $cart);
    if (empty($preflight['valid'])) return $preflight;
    $keys = [];
    // WooCommerce hooks and pricing extensions can throw or change a line
    // during insertion/totals. Keep the batch all-or-nothing.
    try {
        foreach ($preflight['lines'] as $line) {
            $meta = [
                'sanro_studio_design_id' => $line['sanro_studio_design_id'],
                'sanro_studio_size' => $line['sanro_studio_size'],
                'sanro_studio_unit_price' => $line['sanro_studio_unit_price'],
                'sanro_studio_line_subtotal' => $line['sanro_studio_line_subtotal'],
                'sanro_studio_quote_currency' => 'IDR',
            ];
            $key = $cart->add_to_cart($line['product_id'], $line['quantity'], 0, [], $meta);
            if (!is_string($key) || $key === '' || in_array($key, $keys, true)) {
                throw new RuntimeException('cart_add_failed');
            }
            $keys[] = $key;
        }
        $actual = $cart->get_cart();
        $selected = [];
        foreach ($keys as $key) {
            if (!isset($actual[$key]) || !is_array($actual[$key])) {
                throw new RuntimeException('cart_line_missing');
            }
            $selected[] = $actual[$key];
        }
        $priced = sanro_studio_stage_price_cart_batch($contract, $selected);
        if (empty($priced['valid'])) {
            throw new RuntimeException('cart_pricing_failed');
        }
        $cart->calculate_totals();
        $checked = sanro_studio_stage_verify_cart_prices($contract, $cart);
        if (empty($checked['valid'])) {
            throw new RuntimeException('cart_totals_mismatch');
        }
        return ['valid' => true, 'cart_keys' => $keys,
            'total_price' => $priced['total_price'],
            'requires_session_checkout_guard' => true];
    } catch (Throwable $error) {
        // The cart was empty at preflight. A WooCommerce hook may insert a
        // line and then throw before add_to_cart() returns its key. Remove
        // both recorded keys and any untracked line from this failed batch.
        // Never expose exception details or draft credentials in REST.
        $rollback_keys = $keys;
        try {
            $pending = $cart->get_cart();
            if (is_array($pending)) {
                foreach (array_keys($pending) as $pending_key) {
                    if (is_string($pending_key)
                        && !in_array($pending_key, $rollback_keys, true)) {
                        $rollback_keys[] = $pending_key;
                    }
                }
            }
        } catch (Throwable $ignored) {}
        foreach ($rollback_keys as $added) {
            try { $cart->remove_cart_item($added); } catch (Throwable $ignored) {}
        }
        // If the cart could not be rolled back, explicitly fail closed.
        try {
            $remaining = $cart->get_cart();
            if (!is_array($remaining) || $remaining) {
                return ['valid' => false, 'error' => 'cart_rollback_incomplete'];
            }
        } catch (Throwable $ignored) {
            return ['valid' => false, 'error' => 'cart_rollback_incomplete'];
        }
        return ['valid' => false, 'error' => 'cart_transaction_failed'];
    }
}

/**
 * Restore and reprice a cart after session reload ONLY when the caller
 * presents the draft owner token again. Never persist that token in WC.
 * A missing, expired, modified or revoked draft fails closed.
 */
function sanro_studio_stage_reauthorize_cart($design_id, $owner_token, $product_id, $cart) {
    if (!defined('SANRO_STUDIO_ENABLE_STAGING_CART')
        || SANRO_STUDIO_ENABLE_STAGING_CART !== true
        || !is_object($cart) || !method_exists($cart, 'get_cart')
        || !method_exists($cart, 'calculate_totals')
        || !is_int($product_id) || $product_id < 1
        || !function_exists('sanro_studio_prepare_cart_design_contract')) {
        return ['valid' => false, 'error' => 'cart_reauthorization_disabled'];
    }
    $contract = sanro_studio_prepare_cart_design_contract($design_id, $owner_token, $product_id);
    if (empty($contract['valid'])) return $contract;
    $actual = $cart->get_cart();
    if (!is_array($actual) || !$actual) {
        return ['valid' => false, 'error' => 'cart_empty'];
    }
    try {
        $priced = sanro_studio_stage_price_cart_batch($contract, array_values($actual));
        if (empty($priced['valid'])) return $priced;
        $cart->calculate_totals();
        $checked = sanro_studio_stage_verify_cart_prices($contract, $cart);
        if (empty($checked['valid'])) return $checked;
    } catch (Throwable $error) {
        // Session is untrusted on reload; never return a successful price
        // authorization when a WooCommerce hook or pricing extension fails.
        return ['valid' => false, 'error' => 'cart_reprice_failed'];
    }
    return ['valid' => true, 'design_id' => $contract['design_id'],
        'total_price' => $priced['total_price'],
        'requires_checkout_reauthorization' => true];
}
