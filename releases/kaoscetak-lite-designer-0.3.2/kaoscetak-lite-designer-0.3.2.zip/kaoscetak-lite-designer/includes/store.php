<?php
if (!defined('ABSPATH')) exit;
require_once __DIR__.'/validation.php';
add_action('woocommerce_before_calculate_totals',function($cart){
 if(is_admin()&&!wp_doing_ajax())return;
 foreach($cart->get_cart() as $item){
  if(!empty($item['kld_design_id'])&&isset($item['kld_unit_price'])){
   $id=absint($item['kld_design_id']);
   $sides=get_post_meta($id,'_kld_sides',true);$product=absint(get_post_meta($id,'_kld_product',true));
   if(!is_array($sides)||!$product||!is_string($item['kld_size']??null)||!is_object($item['data']??null)||!method_exists($item['data'],'set_price'))continue;
   $price=kld_unit_price($product,$item['kld_size'],$sides['front']['tier']??'none',$sides['back']['tier']??'none');
   if($price!==null){
    $customer=WC()->customer;
    $billing=$customer && method_exists($customer,'get_billing_email')?$customer->get_billing_email():'';
    $item['data']->set_price(kld_repeat_unit_price($id,$price,$billing));
   }
  }
 }
},50);
/** Re-check colour availability on cart/checkout. Disabling a colour must also block an old cart. */
function kld_cart_unavailable_colors($cart){
 $missing=[];
 if(!$cart||!method_exists($cart,'get_cart'))return $missing;
 foreach($cart->get_cart() as $item){
  if(empty($item['kld_design_id']))continue;
  $id=absint($item['kld_design_id']);
  $product=absint(get_post_meta($id,'_kld_product',true));
  $color=(string)($item['kld_color']??'');
  if(!$product||!kld_color_allowed($id,$color))$missing[]=$color?:'(tanpa warna)';
 }
 return array_unique($missing);
}
add_action('woocommerce_check_cart_items',function(){
 if(!function_exists('WC')||!WC()->cart)return;
 foreach(kld_cart_unavailable_colors(WC()->cart) as $name){
  wc_add_notice('Warna '.esc_html($name).' sudah tidak tersedia. Hapus produk custom tersebut dari keranjang lalu pilih warna lain.','error');
 }
 foreach(WC()->cart->get_cart() as $item){
  if(empty($item['kld_design_id']))continue;
  $id=absint($item['kld_design_id']);
  $sides=get_post_meta($id,'_kld_sides',true);
  $product=absint(get_post_meta($id,'_kld_product',true));
  if(!is_array($sides)||!$product||empty($item['kld_size'])||!isset($item['kld_unit_price'])||
   kld_unit_price($product,$item['kld_size'],$sides['front']['tier']??'none',$sides['back']['tier']??'none')===null){
   wc_add_notice('Data atau harga desain custom tidak valid. Hapus item tersebut dari keranjang dan tambahkan kembali.','error');
  }
 }
});
add_action('woocommerce_after_checkout_validation',function($checkout_data,$errors){
 if(!function_exists('WC')||!WC()->cart)return;
 $email=sanitize_email((string)($checkout_data['billing_email']??''));
 foreach(kld_cart_unavailable_colors(WC()->cart) as $name)$errors->add('kld_colour_unavailable','Warna '.sanitize_text_field($name).' sudah tidak tersedia. Hapus item tersebut dari keranjang.');
 foreach(WC()->cart->get_cart() as $item){
  if(empty($item['kld_design_id'])||empty($item['data']))continue;
  $id=absint($item['kld_design_id']);
  $sides=get_post_meta($id,'_kld_sides',true);
  $product=absint(get_post_meta($id,'_kld_product',true));
  if(!is_array($sides)||!$product||!is_string($item['kld_size']??null)||$item['kld_size']===''){
   $errors->add('kld_invalid_design','Data desain tidak lengkap. Hapus produk custom dari keranjang dan tambahkan kembali.');
   continue;
  }
  $base=kld_unit_price($product,$item['kld_size'],$sides['front']['tier']??'none',$sides['back']['tier']??'none');
  if($base===null){
   $errors->add('kld_invalid_price','Kategori cetak atau ukuran desain tidak valid. Perbarui produk custom sebelum checkout.');
   continue;
  }
  $expected=kld_repeat_unit_price($id,$base,$email);
  if(abs((float)$item['data']->get_price()-(float)$expected)>0.01){
   $errors->add('kld_price_mismatch','Harga desain tidak sesuai dengan perhitungan server atau status diskon repeat order. Perbarui checkout dan coba lagi.');
   return;
  }
 }
},20,2);
/** Cart-only preview from the already-saved, size-limited JPEG; never expose Drive masters. */
function kld_cart_preview_image($item){
 $id=kld_positive_id($item['kld_design_id']??0);
 if(!$id)return '';
 foreach(['front','back'] as $side){
  $encoded=(string)get_post_meta($id,'_kld_preview_'.$side,true);
  if($encoded===''||strlen($encoded)>82000||!preg_match('/^[A-Za-z0-9+\/=]+$/D',$encoded))continue;
  $bytes=base64_decode($encoded,true);
  if(!$bytes||strlen($bytes)>61440||substr($bytes,0,2)!=="\xFF\xD8")continue;
  $info=@getimagesizefromstring($bytes);
  if(!$info||$info[2]!==IMAGETYPE_JPEG||$info[0]>1200||$info[1]>1200)continue;
  return '<img src="data:image/jpeg;base64,'.esc_attr($encoded).'" alt="'.esc_attr('Preview desain '.($side==='front'?'depan':'belakang')).'" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" style="width:64px;height:auto;max-width:100%;object-fit:contain" loading="lazy" decoding="async" />';
 }
 return '';
}
add_filter('woocommerce_cart_item_thumbnail',function($thumbnail,$item){
 $preview=kld_cart_preview_image($item);
 return $preview!==''?$preview:$thumbnail;
},10,2);
add_filter('woocommerce_checkout_cart_item_thumbnail',function($thumbnail,$item){
 $preview=kld_cart_preview_image($item);
 return $preview!==''?$preview:$thumbnail;
},10,2);
/** Classic WooCommerce checkout does not render the cart thumbnail hook by default. */
add_filter('woocommerce_cart_item_name',function($name,$item,$key){
 if(!function_exists('is_checkout')||!is_checkout()||(function_exists('is_cart')&&is_cart())||(function_exists('is_order_received_page')&&is_order_received_page()))return $name;
 if(empty($item['kld_design_id']))return $name;
 $preview=kld_cart_preview_image($item);
 if($preview==='')return $name;
 return '<span class="kld-checkout-preview" style="display:inline-block;vertical-align:middle;margin-right:8px;width:64px;max-width:25%">'.$preview.'</span>'.$name;
},20,3);
add_filter('woocommerce_get_item_data',function($data,$item){
 if(empty($item['kld_design_id']))return $data;
 $data[]=['key'=>'Design ID','value'=>'KLD-'.absint($item['kld_design_id'])];
 $s=get_post_meta($item['kld_design_id'],'_kld_sides',true);
 $product=absint(get_post_meta($item['kld_design_id'],'_kld_product',true));
 if(kld_is_mug($product))$data[]=['key'=>'Produk','value'=>'Mug Putih 11 oz | Cetak 18 × 8,5 cm'];
 else $data[]=['key'=>'Ukuran kaos','value'=>sanitize_text_field($item['kld_size'])];
 $data[]=['key'=>kld_is_mug($product)?'Warna mug':'Warna kaos','value'=>sanitize_text_field($item['kld_color'])];
 $data[]=['key'=>kld_is_mug($product)?'Cetak mug':'Cetak depan','value'=>kld_is_mug($product)?'18 × 8,5 cm':sanitize_text_field($s['front']['tier']??'none')];
 if(!kld_is_mug($product))$data[]=['key'=>'Cetak belakang','value'=>sanitize_text_field($s['back']['tier']??'none')];
 return $data;
},10,2);
add_action('woocommerce_checkout_create_order_line_item',function($line,$key,$item,$order){
 if(empty($item['kld_design_id']))return;
 $id=absint($item['kld_design_id']);
 $line->add_meta_data('_kld_design_id',$id,true);
 $product=absint(get_post_meta($id,'_kld_product',true));
 if(kld_is_mug($product))$line->add_meta_data('Produk Cetak','Mug putih 11 oz | 18 x 8.5 cm',true);
 else $line->add_meta_data('Ukuran Kaos',sanitize_text_field($item['kld_size']),true);
 $line->add_meta_data(kld_is_mug($product)?'Warna Mug':'Warna Kaos',sanitize_text_field($item['kld_color']),true);
 $sides=get_post_meta($id,'_kld_sides',true);
 $line->add_meta_data(kld_is_mug($product)?'Area Mug':'Cetak Depan',kld_is_mug($product)?'18 x 8.5 cm':($sides['front']['tier']??'Tanpa cetak'),true);
 if(!kld_is_mug($product))$line->add_meta_data('Cetak Belakang',$sides['back']['tier']??'Tanpa cetak',true);
},10,4);
/** Freeze print layout/master IDs and mockup at checkout; owner edits must not change an order. */
function kld_capture_order_snapshot($order){
 $records=[];
 foreach($order->get_items() as $item){
  $id=absint($item->get_meta('_kld_design_id',true));
  if(!$id||isset($records[$id]))continue;
  $layout=get_post_meta($id,'_kld_sides',true);
  if(!is_array($layout))continue;
  $records[$id]=['sides'=>$layout,'files'=>[],'previews'=>[]];
  foreach(['front','back'] as $side){
   $records[$id]['files'][$side]=(string)get_post_meta($id,'_kld_file_'.$side,true);
   $records[$id]['previews'][$side]=(string)get_post_meta($id,'_kld_preview_'.$side,true);
  }
 }
 if($records)$order->update_meta_data('_kld_order_design_snapshot',$records);
}
add_action('woocommerce_checkout_create_order','kld_capture_order_snapshot',20,1);
add_action('woocommerce_store_api_checkout_update_order_meta','kld_capture_order_snapshot',20,1);
function kld_order_snapshot($order){
 if(!$order||!method_exists($order,'get_meta'))return [];
 $saved=$order->get_meta('_kld_order_design_snapshot',true);
 return is_array($saved)?$saved:[];
}
function kld_order_designs($order){
 $snapshot=kld_order_snapshot($order);$found=[];
 if($snapshot){foreach($snapshot as $id=>$data){if(is_array($data['sides']??null))$found[(int)$id]=$data['sides'];}return $found;}
 // Compatibility path only for legacy orders without a snapshot.
 foreach($order->get_items() as $item){$id=absint($item->get_meta('_kld_design_id',true));if($id && !isset($found[$id]))$found[$id]=get_post_meta($id,'_kld_sides',true);}
 return $found;
}
function kld_render_order_admin($order){
 if(!$order instanceof WC_Order)return;
 $designs=kld_order_designs($order);if(!$designs)return;
 $snapshot=kld_order_snapshot($order);
 echo '<div class="order_data_column_container" style="clear:both;padding:15px 0"><h3>Kaoscetak - Desain & Produksi</h3>';
 foreach($designs as $id=>$sides){
  echo '<div style="border:1px solid #ddd;margin:8px 0;padding:12px"><strong>Desain #'.esc_html($id).'</strong><div style="display:flex;gap:15px;flex-wrap:wrap">';
  foreach(['front'=>'Depan','back'=>'Belakang'] as $side=>$name){
   if($side==='back'&&($sides['front']['tier']??'none')==='MUG')continue;
   if($side==='front'&&($sides['front']['tier']??'none')==='MUG')$name='Bidang Mug';
   $base=$snapshot[$id]['previews'][$side]??get_post_meta($id,'_kld_preview_'.$side,true);
   echo '<div><div>'.esc_html($name).' — '.esc_html($sides[$side]['tier']??'none').'</div>';
   if($base)echo '<img alt="'.esc_attr($name).'" src="data:image/jpeg;base64,'.esc_attr($base).'" width="150" height="150" style="object-fit:contain;border:1px solid #eee">';
   else echo '<em>Tanpa preview</em>';
   echo '</div>';
  }
  echo '</div></div>';
 }
 $folder=$order->get_meta('_kld_drive_order_folder');
 if($folder){echo '<p><strong>File Produksi:</strong> <a href="'.esc_url('https://drive.google.com/drive/folders/'.$folder).'" target="_blank" rel="noopener noreferrer">Buka folder Google Drive</a></p>';} 
 else {echo '<p><strong>File Produksi:</strong> Belum tersedia (menunggu pembayaran / siap produksi).</p>';
 $link=wp_nonce_url(admin_url('admin-post.php?action=kld_ready_order&order='.$order->get_id()),'kld_ready_'.$order->get_id());
 echo '<p><a class="button" href="'.esc_url($link).'">Tandai Siap Produksi & Siapkan Drive</a></p>';}
 $error=$order->get_meta('_kld_drive_last_error');if($error)echo '<p style="color:#a00">Status sinkronisasi terakhir: '.esc_html($error).'</p>';
 echo '</div>';
}
add_action('woocommerce_admin_order_data_after_order_details','kld_render_order_admin');
add_action('woocommerce_order_status_processing','kld_auto_production',20);
add_action('woocommerce_order_status_completed','kld_auto_production',20);
function kld_auto_production($order_id){
 if(function_exists('as_enqueue_async_action'))as_enqueue_async_action('kld_prepare_production_job',['order_id'=>(int)$order_id],'kaoscetak-lite-designer',true);
 elseif(!wp_next_scheduled('kld_prepare_production_job',[(int)$order_id]))wp_schedule_single_event(time()+5,'kld_prepare_production_job',[(int)$order_id]);
}
add_action('kld_prepare_production_job','kld_run_production_job');
function kld_run_production_job($order_id){
 $order=wc_get_order($order_id);
 if(!$order||!$order->is_paid())return;
 $r=kld_prepare_production($order);
 if(is_wp_error($r))$order->add_order_note('Kaoscetak: penyiapan Google Drive gagal: '.$r->get_error_message());
}
add_action('admin_post_kld_ready_order',function(){
 $id=absint($_GET['order']??0);
 if(!$id||!current_user_can('edit_shop_orders'))wp_die('Tidak memiliki hak akses.');
 check_admin_referer('kld_ready_'.$id);
 $order=wc_get_order($id);if(!$order)wp_die('Pesanan tidak ditemukan.');
 $r=kld_prepare_production($order);
 if(is_wp_error($r))$order->add_order_note('Kaoscetak: sinkronisasi produksi gagal: '.$r->get_error_message());
 wp_safe_redirect($order->get_edit_order_url());exit;
});
function kld_prepare_production($order){
 if(!$order)return new WP_Error('order','Pesanan tidak ditemukan.');
 $existing=$order->get_meta('_kld_drive_order_folder');
 if($existing)return $existing;
 $designs=kld_order_designs($order);if(!$designs)return new WP_Error('no_design','Tidak ada desain Kaoscetak pada pesanan ini.');
 $snapshot=kld_order_snapshot($order);
 if(!kld_drive_connected())return new WP_Error('no_drive','Google Drive belum terhubung.');
 $lockkey='kld_prod_lock_'.$order->get_id();
 $lock=kld_lock_acquire($lockkey,300);
 if(!$lock)return new WP_Error('locked','Sinkronisasi sedang berjalan.');
 try {
  $roots=kld_drive_roots();if(is_wp_error($roots))throw new RuntimeException($roots->get_error_message());
  $folder=$order->get_meta('_kld_drive_order_pending');
  if(!$folder){$folder=kld_drive_order_folder($order,$roots['orders']);if(is_wp_error($folder))throw new RuntimeException($folder->get_error_message());$order->update_meta_data('_kld_drive_order_pending',$folder);$order->save();}
  // Durable provider IDs protect the interval before each order completion marker is saved.
  foreach($designs as $id=>$sides){
   foreach(['front','back'] as $side){
    if(($sides[$side]['tier']??'none')==='none')continue;
    $fileid=$snapshot[$id]['files'][$side]??get_post_meta($id,'_kld_file_'.$side,true);if(!$fileid)continue;
    $tag='_kld_sc_'.$id.'_'.$side;
    if($order->get_meta($tag))continue;
    $artifactKey=hash('sha256',home_url('/').'|shortcut|'.$order->get_id().'|'.$id.'|'.$side.'|'.$fileid);
    $r=kld_drive_shortcut($fileid,$folder,'DESAIN-'.$id.'-'.strtoupper($side),$artifactKey);
    if(is_wp_error($r))throw new RuntimeException($r->get_error_message());
    $order->update_meta_data($tag,$r['id']);$order->save();
   }
  }
  foreach($designs as $designid=>$layout){
   $guidekey='_kld_guide_uploaded_'.(int)$designid;
   if($order->get_meta($guidekey))continue;
   $pdf=kld_make_guide_pdf($order,[$designid=>$layout]);
   if(is_wp_error($pdf))throw new RuntimeException($pdf->get_error_message());
   $artifactKey=hash('sha256',home_url('/').'|guide|'.$order->get_id().'|'.$designid);
   $r=kld_drive_upload_small('ORDER-'.$order->get_order_number().'-DESAIN-'.$designid.'-PANDUAN.pdf','application/pdf',$pdf,$folder,$artifactKey);
   if(is_wp_error($r))throw new RuntimeException($r->get_error_message());
   $order->update_meta_data($guidekey,$r['id']);$order->save();
  }
  $order->update_meta_data('_kld_drive_order_folder',$folder);
  $order->delete_meta_data('_kld_drive_last_error');$order->save();
  $order->add_order_note('Kaoscetak: folder Google Drive dan PDF panduan produksi tersedia.');
  return $folder;
 }catch(Throwable $e){
  $order->update_meta_data('_kld_drive_last_error',$e->getMessage());$order->save();
  return new WP_Error('production_failed',$e->getMessage());
 }finally{kld_lock_release($lockkey,$lock);}
}
function kld_drive_upload_small($name,$mime,$bytes,$parent,$key=''){
 if(strlen($bytes)>1000000)return new WP_Error('too_large','Panduan produksi melebihi 1 MB.');
 $meta=['name'=>$name,'mimeType'=>$mime,'parents'=>[$parent]];
 if($key!==''){
  if($mime!=='application/pdf')return new WP_Error('artifact_type','Panduan produksi harus berupa PDF.');
  $plan=kld_drive_artifact_plan($parent,$key,$mime);if(is_wp_error($plan))return $plan;
  $meta=array_merge($meta,$plan);$existing=kld_drive_artifact_probe($meta);
  if($existing!==false)return $existing;
 }
 $token=kld_drive_token();if(is_wp_error($token))return $token;
 $boundary='kld'.bin2hex(random_bytes(8));
 $metadata=wp_json_encode($meta);
 $body='--'.$boundary."\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".$metadata."\r\n";
 $body.='--'.$boundary."\r\nContent-Type: ".$mime."\r\n\r\n".$bytes."\r\n--".$boundary."--\r\n";
 $r=wp_remote_post('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name',[
  'timeout'=>40,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'multipart/related; boundary='.$boundary], 'body'=>$body]);
 if($key!=='')return kld_drive_artifact_finish($meta,$r);
 if(is_wp_error($r))return $r;
 $data=json_decode(wp_remote_retrieve_body($r),true);
 if(wp_remote_retrieve_response_code($r)<200||wp_remote_retrieve_response_code($r)>=300||empty($data['id']))return new WP_Error('drive_pdf','Upload PDF panduan gagal (HTTP '.wp_remote_retrieve_response_code($r).').');
 return $data;
}
/** Minimal valid PDF with native JPEG mockups (no heavyweight image rendering on hosting). */
function kld_make_guide_pdf($order,$designs){
 $snapshot=kld_order_snapshot($order);
 $objects=[];
 $add=function($s)use(&$objects){$objects[]=$s;return count($objects);};
 $catalog=$add('');$pages=$add('');$page=$add('');$font=$add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
 $xobjs=[];$stream='';$y=790;
 $esc=function($s){$s=remove_accents((string)$s);$s=preg_replace('/[^\x20-\x7E]/','?',$s);return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$s);};
 $line=function($text,$size=11,$x=40)use(&$stream,&$y,$esc){$stream.="BT /F1 {$size} Tf {$x} {$y} Td (".$esc($text).") Tj ET\n";$y-=($size+8);};
 $line('KAOSCETAK - PANDUAN PRODUKSI',17);
 $line('ORDER #'.$order->get_order_number().' | '.wp_date('d-m-Y H:i'),10);
 $line('Jenis output: FILE ASLI + PANDUAN. Siapkan file cetak sesuai jenis produk di komputer produksi.',9);
 $line('Ukuran fisik mengikuti tata letak desain dan kategori area yang dipilih.',9);
 foreach($order->get_items() as $item){
  $id=absint($item->get_meta('_kld_design_id',true));if(!$id||!isset($designs[$id]))continue;
  $line('Produk: '.$item->get_name().' | Qty '.$item->get_quantity().' | '.($item->get_meta('Produk Cetak')?:$item->get_meta('Ukuran Kaos')).' | '.($item->get_meta('Warna Mug')?:$item->get_meta('Warna Kaos')),10);
 }
 foreach($designs as $id=>$sides){
  if($y<350){$line('Lihat rincian desain tambahan di metadata order WooCommerce.',10);break;}
  $line('DESAIN #'.$id,13);
  foreach(['front'=>'DEPAN','back'=>'BELAKANG'] as $side=>$name){
   if($side==='back'&&($sides['front']['tier']??'none')==='MUG')continue;
   $d=$sides[$side]??[];
   $line(($d['tier']??'none')==='MUG'?'MUG PUTIH 11 oz | Bidang maks. 18 x 8.5 cm':$name.' | Kategori: '.($d['tier']??'none'),11);
   if(!empty($d['actual_cm']))$line('Gabungan aktual: '.$d['actual_cm']['width'].' x '.$d['actual_cm']['height'].' cm',9);
   if(!empty($d['needs_bg_removal']))$line('PERHATIAN: hapus background dari FILE ASLI di komputer produksi.',9);
   if(($d['tier']??'none')!=='none'){
    $position=$d['placement']??[];
    if(($d['tier']??'none')==='MUG')$line('Acuan posisi X/Y adalah pojok kiri atas bidang 18 x 8.5 cm (terbentang).',9);
    else $line('Posisi cetak: geser tengah '.($position['center_offset_cm']??0).' cm | Jarak dari kerah '.($position['top_from_collar_cm']??10.83).' cm',9);
   }
   foreach(['image'=>'Gambar','text'=>'Teks'] as $key=>$label){
    if(!empty($d[$key])){
     $v=$d[$key];
     $line($label.': '.($v['w']??'?').' x '.($v['h']??'?').' cm | X '.($v['x']??'?').' cm | Y '.($v['y']??'?').' cm',9);
     if($key==='text'){
      $line('Teks: '.preg_replace('/\s+/',' ',(string)($v['value']??'')),9);
      $line('Font: '.($v['font']??'Arial').' | Warna: '.($v['color']??'#ffffff'),9);
     }
    }
   }
  }
  $imgs=[];
  foreach(['front','back'] as $side){
   $raw=base64_decode((string)($snapshot[$id]['previews'][$side]??get_post_meta($id,'_kld_preview_'.$side,true)),true);
   if(!$raw||strlen($raw)>61440||substr($raw,0,2)!=="\xFF\xD8")continue;
   $info=@getimagesizefromstring($raw);if(!$info||$info[2]!==IMAGETYPE_JPEG)continue;
   $imgName='Im'.(count($xobjs)+1);
   $obj=$add('<< /Type /XObject /Subtype /Image /Width '.(int)$info[0].' /Height '.(int)$info[1].' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '.strlen($raw).' >>' ."\nstream\n".$raw."\nendstream");
   $xobjs[$imgName]=$obj;$imgs[]=$imgName;
  }
  if($imgs){
   $y-=148;$x=45;
   foreach($imgs as $name){$stream.="q 130 0 0 130 {$x} {$y} cm /{$name} Do Q\n";$x+=170;}
  }
  $y-=12;
 }
 $line('Catatan: ukuran cetak final dan profil warna dicek operator sebelum produksi.',9);
 $resources='<< /Font << /F1 '.$font.' 0 R >>';
 if($xobjs){$resources.=' /XObject <<';foreach($xobjs as $name=>$id)$resources.=' /'.$name.' '.$id.' 0 R';$resources.=' >>';}
 $resources.=' >>';
 $content=$add('<< /Length '.strlen($stream).' >>'."\nstream\n".$stream."endstream");
 $objects[$catalog-1]='<< /Type /Catalog /Pages '.$pages.' 0 R >>';
 $objects[$pages-1]='<< /Type /Pages /Kids ['.$page.' 0 R] /Count 1 >>';
 $objects[$page-1]='<< /Type /Page /Parent '.$pages.' 0 R /MediaBox [0 0 595 842] /Resources '.$resources.' /Contents '.$content.' 0 R >>';
 $pdf="%PDF-1.4\n%KLD\n";$offsets=[0];
 foreach($objects as $i=>$obj){$offsets[]=strlen($pdf);$pdf.=($i+1)." 0 obj\n".$obj."\nendobj\n";}
 $xref=strlen($pdf);$pdf.='xref' ."\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";
 for($i=1;$i<=count($objects);$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i])."\n";
 $pdf.='trailer << /Size '.(count($objects)+1).' /Root '.$catalog.' 0 R >>'."\nstartxref\n".$xref."\n%%EOF";
 return $pdf;
}

// Revalidate immutable design, current product policy and master availability at native gates.
add_action('woocommerce_check_cart_items',function(){
 if(!function_exists('WC')||!WC()->cart)return;
 foreach(kld_validate_cart_designs(WC()->cart) as $message)wc_add_notice($message,'error');
});
add_action('woocommerce_after_checkout_validation',function($data,$errors){
 if(!WC()->cart)return;
 foreach(kld_validate_cart_designs(WC()->cart,true) as $message)$errors->add('kld_design_unavailable',$message);
},30,2);
add_filter('woocommerce_store_api_cart_errors',function($errors,$cart){
 foreach($cart->get_cart() as $item)if(!empty($item['kld_design_id'])){$errors->add('kld_classic_required','Kaoscetak Lite Designer RC memerlukan Classic Checkout. Hubungi admin untuk halaman checkout yang kompatibel.');break;}
 foreach(kld_validate_cart_designs($cart,true) as $message)$errors->add('kld_design_unavailable',$message);
 return $errors;
},10,2);
